"""
Configuration for the generate module
"""

#-----------------------------------------------------------------------------#
# Flags for running on CPU
#-----------------------------------------------------------------------------#
FLAG_CPU_MODE = True
#FLAG_CPU_MODE = False

#-----------------------------------------------------------------------------#
# Paths to models and biases
#-----------------------------------------------------------------------------#
paths = dict()

# Skip-thoughts
paths['skmodels'] = 'models/'#dont know
paths['sktables'] = 'models/'

# Decoder
paths['decmodel'] = 'storyteller/romance.npz'
paths['dictionary'] = 'storyteller/romance_dictionary.pkl'

# Image-sentence embedding
paths['vsemodel'] = 'storyteller/coco_embedding.npz'

# VGG-19 convnet
paths['vgg'] = 'vgg/vgg19.pkl'
#paths['pycaffe'] = ''
paths['pycaffe'] = 'C:/Python27/Caffe/python/caffe'
#paths['pycaffe'] = '/u/yukun/Projects/caffe-run/python'#dont know
paths['vgg_proto_caffe'] = 'vgg/VGG_ILSVRC_19_layers_deploy.prototxt'
paths['vgg_model_caffe'] = 'vgg/VGG_ILSVRC_19_layers.caffemodel'


# COCO training captions
paths['captions'] = 'storyteller/coco_train_caps.txt'

# Biases
paths['negbias'] = 'storyteller/caption_style.npy'
paths['posbias'] = 'storyteller/romance_style.npy'
