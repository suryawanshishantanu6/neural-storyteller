import generate
z = generate.load_all()
s = generate.story(z, 'images/ex1.jpg')
print (s)